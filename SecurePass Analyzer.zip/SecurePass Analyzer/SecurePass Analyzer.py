import re

password = input("Enter your password: ")

score = 0

# Check conditions
if len(password) >= 8:
    score += 1
else:
    print(" Password should be at least 8 characters long")

if re.search(r"[A-Z]", password):
    score += 1
else:
    print(" Add at least one uppercase letter")

if re.search(r"[a-z]", password):
    score += 1
else:
    print(" Add at least one lowercase letter")

if re.search(r"\d", password):
    score += 1
else:
    print(" Include at least one number")

if re.search(r"[!@#$%^&*]", password):
    score += 1
else:
    print(" Include at least one special character")

# Strength result
print("\nPassword Strength:", end=" ")

if score <= 2:
    print("Weak")
elif score == 3:
    print("Moderate")
elif score == 4:
    print("Strong")
else:
    print("Very Strong")